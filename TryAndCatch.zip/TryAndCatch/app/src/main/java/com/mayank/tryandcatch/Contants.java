package com.mayank.tryandcatch;

/**
 * Created by trycatch on 03/08/18.
 */

public class Contants {
    public static final String FIREBASE_TOKEN = "firebase token";

}
